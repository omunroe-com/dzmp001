defmodule Crawler.DispatcherTest do
  use Crawler.TestCase, async: true

  doctest Crawler.Dispatcher
end
