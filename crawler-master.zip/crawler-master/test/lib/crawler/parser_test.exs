defmodule Crawler.ParserTest do
  use Crawler.TestCase, async: true

  alias Crawler.{Parser, Store.Page}

  doctest Parser
end
