defmodule Crawler.Snapper.LinkReplacerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Snapper.LinkReplacer

  doctest LinkReplacer
end
