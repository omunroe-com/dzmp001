defmodule Crawler.Snapper.DirMakerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Snapper.DirMaker

  doctest DirMaker
end
