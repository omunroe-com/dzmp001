defmodule Crawler.Parser.CssParserTest do
  use Crawler.TestCase, async: true

  alias Crawler.Parser.CssParser

  doctest CssParser
end
