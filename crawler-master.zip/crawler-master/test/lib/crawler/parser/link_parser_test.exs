defmodule Crawler.Parser.LinkParserTest do
  use Crawler.TestCase, async: true

  alias Crawler.Parser.LinkParser

  doctest LinkParser
end
