defmodule Crawler.Parser.LinkParser.LinkExpanderTest do
  use Crawler.TestCase, async: true

  alias Crawler.Parser.LinkParser.LinkExpander

  doctest LinkExpander
end
