defmodule Crawler.Parser.GuarderTest do
  use Crawler.TestCase, async: true

  alias Crawler.Parser.Guarder

  doctest Guarder
end
