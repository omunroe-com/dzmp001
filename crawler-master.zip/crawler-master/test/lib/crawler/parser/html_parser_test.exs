defmodule Crawler.Parser.HtmlParserTest do
  use Crawler.TestCase, async: true

  alias Crawler.Parser.HtmlParser

  doctest HtmlParser
end
