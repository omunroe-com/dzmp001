defmodule Crawler.LinkerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker

  doctest Linker
end
