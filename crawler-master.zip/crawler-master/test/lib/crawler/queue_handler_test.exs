defmodule Crawler.QueueHandlerTest do
  use Crawler.TestCase, async: true

  alias Crawler.QueueHandler

  doctest QueueHandler
end
