defmodule Crawler.Fetcher.RetrierTest do
  use Crawler.TestCase, async: true

  alias Crawler.Fetcher.Retrier

  doctest Retrier
end
