defmodule Crawler.Fetcher.RequesterTest do
  use Crawler.TestCase, async: true

  alias Crawler.Fetcher.Requester

  doctest Requester
end
