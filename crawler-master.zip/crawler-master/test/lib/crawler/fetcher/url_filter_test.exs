defmodule Crawler.Fetcher.UrlFilterTest do
  use Crawler.TestCase, async: true

  alias Crawler.Fetcher.UrlFilter

  doctest UrlFilter
end
