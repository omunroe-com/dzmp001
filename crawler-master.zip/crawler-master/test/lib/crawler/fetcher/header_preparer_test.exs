defmodule Crawler.Fetcher.HeaderPreparerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Fetcher.HeaderPreparer

  doctest HeaderPreparer
end
