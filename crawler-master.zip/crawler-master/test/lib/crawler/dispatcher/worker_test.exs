defmodule Crawler.Dispatcher.WorkerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Dispatcher.Worker

  doctest Worker
end
