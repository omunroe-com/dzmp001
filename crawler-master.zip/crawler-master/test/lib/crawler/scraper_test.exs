defmodule Crawler.ScraperTest do
  use Crawler.TestCase, async: true

  alias Crawler.Scraper

  doctest Scraper
end
