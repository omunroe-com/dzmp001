defmodule Crawler.SnapperTest do
  use Crawler.TestCase, async: true

  alias Crawler.Snapper

  doctest Snapper
end
