defmodule Crawler.OptionsTest do
  use Crawler.TestCase, async: true

  alias Crawler.Options

  doctest Options
end
