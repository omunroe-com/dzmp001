defmodule Crawler.Linker.PathOfflinerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker.PathOffliner

  doctest PathOffliner
end
