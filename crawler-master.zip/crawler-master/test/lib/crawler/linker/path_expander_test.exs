defmodule Crawler.Linker.PathExpanderTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker.PathExpander

  doctest PathExpander
end
