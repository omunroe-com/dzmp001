defmodule Crawler.Linker.PathBuilderTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker.PathBuilder

  doctest PathBuilder
end
