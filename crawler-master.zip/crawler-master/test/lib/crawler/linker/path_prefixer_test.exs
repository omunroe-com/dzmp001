defmodule Crawler.Linker.PathPrefixerTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker.PathPrefixer

  doctest PathPrefixer
end
