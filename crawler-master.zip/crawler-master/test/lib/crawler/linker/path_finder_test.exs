defmodule Crawler.Linker.PathFinderTest do
  use Crawler.TestCase, async: true

  alias Crawler.Linker.PathFinder

  doctest PathFinder
end
