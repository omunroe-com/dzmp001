defmodule Crawler.WorkerTest do
  use Crawler.TestCase, async: true

  doctest Crawler.Worker
end
