defmodule Crawler.HTTP do
  @moduledoc """
  Custom HTTPoison base module for potential customisation.
  """

  use HTTPoison.Base
end
