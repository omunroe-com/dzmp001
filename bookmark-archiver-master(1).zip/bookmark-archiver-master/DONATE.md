# Donate

Right now I'm working on this project in my spare time and accepting the occational PR,   
if you want me to dedicate more time to it, donate to support development!

 - Ethereum: 0x5B0F85FFc44fD759C2d97f0BE4681279966f3832
 - Bitcoin: https://shapeshift.io/ BTC -> to address above (ETH)
 - Paypal: https://www.paypal.me/NicholasSweeting/25

The eventual goal is to support one or two developers full-time on this project via donations.   
With more engineering power this can become a distributed archive service with a nice UI,   
like the Way-Back machine but hosted by everyone!

If have any questions or want to sponsor this project long-term, contact me at  
bookmark-archiver@sweeting.me
