# Working of Cohem Sutherland Line-clipping

## Enter the co-ordinates
Enter x1 and y1 
## `100` `100`

Enter x2 and y2
## `200` `200`



## Before Clipping -

![negative image_1507903193982](https://user-images.githubusercontent.com/31897425/31549852-0605958c-b04d-11e7-8f5f-2c5a636b6746.jpg)


## After Clipping -

![negative image_1507903215353](https://user-images.githubusercontent.com/31897425/31549886-1f50d524-b04d-11e7-8f50-5f27f57595d5.jpg)

---

<p align="center">
	A massive collaborative effort by <a href="https://github.com/OpenGenus/cosmos">OpenGenus Foundation</a> 
</p>

---
