# cosmos
Your personal library of every algorithm and data structure code that you will ever encounter

## 2 Dimensional line intersection

This package contains programs for 2D line intersections.

The program checks if two lines are `parallel` or `intersecting`. If they intersect, it gives the point of intersection.

<p align="center">
	A massive collaborative effort by <a href="https://github.com/OpenGenus/cosmos">OpenGenus Foundation</a> 
</p>