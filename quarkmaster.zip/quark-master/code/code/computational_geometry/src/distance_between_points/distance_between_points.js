function distanceBetweenPoints (x1, x2, y1, y2) {
  return Math.hypot(x1, x2, y1, y2);
}

console.log(distanceBetweenPoints(0,3,0,4))
