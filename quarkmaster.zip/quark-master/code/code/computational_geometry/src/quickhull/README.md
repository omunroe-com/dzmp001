# Quickhull
For theoretical background see [Quickhull](https://en.wikipedia.org/wiki/Quickhull).
Test data can be found in `test_data.csv`. 

Example of convex hull of a set of points:

![result](https://github.com/chronologos/cosmos/blob/master/code/computational_geometry/quickhull/test_data_soln.png?raw=true)
