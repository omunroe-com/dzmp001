# cosmos
> Your personal library of every algorithm and data structure code that you will ever encounter

# Cellular Automaton

---

<p align="center">
	A massive collaborative effort by <a href="https://github.com/OpenGenus/cosmos">OpenGenus Foundation</a> 
</p>

---
