# cosmos
Your personal library of every algorithm and data structure code that you will ever encounter
SubsetSum is  to compute a sum S using a selected subset of a given set of N weights.

It works by backtracking, returning all possible solutions one at a time, keeping track of the selected weights using a 0/1 mask vector of size N.

A={1,2,3,4,7}
S=4
subets={1,3},{4}
