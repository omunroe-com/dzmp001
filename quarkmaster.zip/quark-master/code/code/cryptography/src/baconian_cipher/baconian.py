# Part of Cosmos by OpenGenus Foundation
baconian_codes = {'a' : 'AAAAA', 'b' : 'AAAAB', 'c' : 'AAABA', 'd' :
'AAABB', 'e' : 'AABAA', 'f' : 'AABAB', 'g' : 'AABBA', 'h' : 'AABBB',
'i' : 'ABAAA', 'j' : 'BBBAA', 'k' : 'ABAAB', 'l' : 'ABABA', 'm' :
'ABABB', 'n' : 'ABBAA', 'o' : 'ABBAB', 'p' : 'ABBBA', 'q' : 'ABBBB',
'r' : 'BAAAA', 's' : 'BAAAB', 't' : 'BAABA', 'u' : 'BAABB', 'v' :
'BBBAB', 'w' : 'BABAA', 'x' : 'BABAB', 'y' : 'BABBA', 'z' : 'BABBB'}

if __name__ == '__main__':
	plaintext = 'Text to be encrypted'
	ciphertext = ''
	for ch in plaintext:
		if ch != ' ':
			ciphertext += baconian_codes[ch.lower()]
		else:
			ciphertext += ' '
	print ciphertext
