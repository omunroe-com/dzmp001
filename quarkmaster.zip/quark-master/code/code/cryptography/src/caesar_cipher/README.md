# Caesar Cipher
The Caesar Cipher is a simple cipher which changes each letter in a given phrase from to another letter of the alphabet by shifting each letter by a certain number of places.

## Example

This example uses a right shift of 2.

```text
A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
| | | | | | | | | | | | | | | | | | | | | | | | | |
V V V V V V V V V V V V V V V V V V V V V V V V V V
C D E F G H I J K L M N O P Q R S T U V W X Y Z A B

THIS IS HOW THE CIPHER WORKS
VJKU KU JQY VJG EKRJGT YQTMU

```
