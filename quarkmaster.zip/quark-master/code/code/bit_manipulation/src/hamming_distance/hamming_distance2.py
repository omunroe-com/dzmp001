def main():
    num = raw_input("enter a number")
    return ('{0:08b}'.format(x)).count("1")


if __name__ == '__main__':
    main()
